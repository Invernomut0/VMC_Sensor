DOMAIN = "vmc_sensor"


async def async_setup(hass, config):
    """Set up the VMC SENSOR sensor component."""
    return True
